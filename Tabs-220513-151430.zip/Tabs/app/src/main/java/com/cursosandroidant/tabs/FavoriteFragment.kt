package com.cursosandroidant.tabs

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.size
import androidx.fragment.app.Fragment
import androidx.viewpager.widget.ViewPager
import com.cursosandroidant.tabs.databinding.FragmentFavoriteBinding

/****
 * Project: Tabs
 * From: com.cursosandroidant.tabs
 * Created by Alain Nicolás Tello on 03/05/22 at 16:02
 * All rights reserved 2022.
 *
 * All my Udemy Courses:
 * https://www.udemy.com/user/alain-nicolas-tello/
 * Web: www.alainnicolastello.com
 ***/
class FavoriteFragment : Fragment() {
    
    private var binding: FragmentFavoriteBinding? = null
    
    override fun onCreateView(
     inflater: LayoutInflater,
     container: ViewGroup?,
     savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        binding?.let { return  it.root }
        
        return super.onCreateView(inflater, container, savedInstanceState)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val source = arrayOf("https://upload.wikimedia.org/wikipedia/en/d/da/SAC_Namibia-desert-3.jpg",
         "https://live.staticflickr.com/1100/1155225799_54edad365f_b.jpg",
         "https://pixnio.com/free-images/nature-landscapes/underwater/colorful-underwater-landscape-of-a-coral-reef-725x483.jpg")
        
        val galleryAdapter = GalleryAdapter(source)
        binding?.let { bind ->
            bind.vpGallery.adapter = galleryAdapter
            bind.ibBefore.setOnClickListener { beforeImage(bind.vpGallery) }
            bind.ibNext.setOnClickListener { nextImage(bind.vpGallery) }
        }
    }
    
    private fun beforeImage(viewPager: ViewPager){
        if (viewPager.currentItem > 0) viewPager.currentItem -= 1
    }
    
    private fun nextImage(viewPager: ViewPager){
        if (viewPager.currentItem < viewPager.size - 1) viewPager.currentItem += 1
    }
}