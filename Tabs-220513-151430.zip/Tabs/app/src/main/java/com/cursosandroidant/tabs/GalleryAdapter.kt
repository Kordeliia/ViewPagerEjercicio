package com.cursosandroidant.tabs

import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.viewpager.widget.PagerAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy

/****
 * Project: Tabs
 * From: com.cursosandroidant.tabs
 * Created by Alain Nicolás Tello on 04/05/22 at 12:17
 * All rights reserved 2022.
 *
 * All my Udemy Courses:
 * https://www.udemy.com/user/alain-nicolas-tello/
 * Web: www.alainnicolastello.com
 ***/
class GalleryAdapter(private val urls: Array<String>) : PagerAdapter() {
    override fun getCount(): Int = urls.size
    
    override fun isViewFromObject(view: View, `object`: Any): Boolean = view == `object`
    
    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val imageView = ImageView(container.context)
        
        Glide.with(container.context)
            .load(urls[position])
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .centerCrop()
            .into(imageView)
        
        container.addView(imageView, 0)
        return imageView
    }
    
    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as ImageView)
    }
}