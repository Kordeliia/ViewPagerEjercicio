package com.cursosandroidant.tabs

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter

/****
 * Project: Tabs
 * From: com.cursosandroidant.tabs
 * Created by Alain Nicolás Tello on 03/05/22 at 16:07
 * All rights reserved 2022.
 *
 * All my Udemy Courses:
 * https://www.udemy.com/user/alain-nicolas-tello/
 * Web: www.alainnicolastello.com
 ***/
class FragmentsAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle) :
    FragmentStateAdapter(fragmentManager, lifecycle) {
 
    override fun getItemCount(): Int = 3
    
    override fun createFragment(position: Int): Fragment = when(position){
        0 -> HomeFragment()
        1 -> CartFragment()
        else -> FavoriteFragment()
    }
}