package com.cursosandroidant.tabs

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

/****
 * Project: Tabs
 * From: com.cursosandroidant.tabs
 * Created by Alain Nicolás Tello on 03/05/22 at 15:58
 * All rights reserved 2022.
 *
 * All my Udemy Courses:
 * https://www.udemy.com/user/alain-nicolas-tello/
 * Web: www.alainnicolastello.com
 ***/
class HomeFragment : Fragment(){
    override fun onCreateView(
     inflater: LayoutInflater,
     container: ViewGroup?,
     savedInstanceState: Bundle?
    ): View? {
         return inflater.inflate(R.layout.fragment_home, container, false)
    }
}