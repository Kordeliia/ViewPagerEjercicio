val source = arrayOf("https://upload.wikimedia.org/wikipedia/en/d/da/SAC_Namibia-desert-3.jpg",
            "https://live.staticflickr.com/1100/1155225799_54edad365f_b.jpg",
            "https://pixnio.com/free-images/nature-landscapes/underwater/colorful-underwater-landscape-of-a-coral-reef-725x483.jpg")